<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="Merchant" tilewidth="32" tileheight="32" tilecount="16" columns="4">
 <image source="../../graphics/images/merchant.png" width="128" height="128"/>
</tileset>
