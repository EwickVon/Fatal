<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="Trees" tilewidth="32" tileheight="32" tilecount="16" columns="4">
 <image source="../../graphics/Terrain/Tree/Tree_tileset.png" width="130" height="130"/>
</tileset>
