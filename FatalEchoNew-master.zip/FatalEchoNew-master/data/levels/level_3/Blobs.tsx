<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="Blobs" tilewidth="97" tileheight="30" tilecount="1" columns="1">
 <image source="../../graphics/images/blob_img.png" width="97" height="30"/>
</tileset>
